document.addEventListener("DOMContentLoaded", () => {
    console.log("JavaScript is successfully connected!");

    console.log("--- PART 3: SEARCH ENGINE OPTIMIZATION (SEO) STRATEGY ---");
    console.log("1. Meta Tags: Title matches semantic keyword intents like 'Luxury Riverlea Stay'.");
    console.log("2. Image Optimization: Alt descriptors and specific image sizes planned for fast rendering.");
    console.log("3. Semantic HTML Structure: Strict usage of <header>, <nav>, <main>, and <footer> components.");

    const mapContainer = document.getElementById("hotel-map");
    if (mapContainer && typeof L !== "undefined") {
        const map = L.map("hotel-map").setView([-26.2150, 27.9750], 14);
        L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png").addTo(map);
        L.marker([-26.2150, 27.9750]).addTo(map).bindPopup("White Wall Guesthouse").openPopup();
        
        setTimeout(() => { 
            map.invalidateSize(); 
        }, 200);
    }

    const searchInput = document.getElementById("room-search-input");
    if (searchInput) {
        searchInput.addEventListener("input", () => {
            const query = searchInput.value.toLowerCase();
            const cards = document.querySelectorAll(".room-card");
            cards.forEach(card => {
                const text = card.textContent.toLowerCase();
                if (text.includes(query)) {
                    card.style.display = "block";
                } else {
                    card.style.display = "none";
                }
            });
        });
    }

    const lightbox = document.createElement('div');
    lightbox.id = 'gallery-lightbox';
    lightbox.style.position = 'fixed';
    lightbox.style.zIndex = '2000';
    lightbox.style.top = '0';
    lightbox.style.left = '0';
    lightbox.style.width = '100%';
    lightbox.style.height = '100%';
    lightbox.style.backgroundColor = 'rgba(0, 0, 0, 0.9)';
    lightbox.style.display = 'none';
    lightbox.style.justifyContent = 'center';
    lightbox.style.alignItems = 'center';
    lightbox.style.cursor = 'zoom-out';

    const lightboxImg = document.createElement('img');
    lightboxImg.style.maxWidth = '85%';
    lightboxImg.style.maxHeight = '85%';
    lightboxImg.style.border = '2px solid #d4af37';
    lightboxImg.style.boxShadow = '0 0 30px rgba(0,0,0,0.5)';
    lightbox.appendChild(lightboxImg);
    document.body.appendChild(lightbox);

    const roomImages = document.querySelectorAll('.grid-3 img');
    roomImages.forEach(image => {
        image.style.cursor = 'zoom-in';
        image.addEventListener('click', () => {
            lightboxImg.src = image.src;
            lightbox.style.display = 'flex';
        });
    });

    lightbox.addEventListener('click', () => {
        lightbox.style.display = 'none';
    });

    const contactForm = document.getElementById("guesthouse-contact");
    if (contactForm) {
        contactForm.addEventListener("submit", async (e) => {
            e.preventDefault();
            const name = document.getElementById("guest-name").value.trim();
            const email = document.getElementById("guest-email").value.trim();
            const msgType = document.getElementById("msg-type").value;
            const message = document.getElementById("guest-msg").value.trim();
            const btn = document.getElementById("submit-contact-btn");

            if (!name || !email || !message) {
                alert("Please fill out all fields.");
                return;
            }

            btn.value = "Sending...";
            btn.disabled = true;

            try {
                const response = await fetch("https://httpbin.org", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ name, email, msgType, message })
                });

                if (response.ok) {
                    btn.value = "Sent Successfully!";
                    btn.style.backgroundColor = "#c5a880";
                    contactForm.reset();
                } else {
                    throw new Error();
                }
            } catch (err) {
                alert("Submission failed. Please try again.");
                btn.value = "Send Message";
                btn.disabled = false;
            }
        });
    }

    const enquiryForm = document.getElementById("enquiry-form");
    if (enquiryForm) {
        enquiryForm.addEventListener("submit", async (e) => {
            e.preventDefault();
            const rate = parseInt(document.getElementById("room-type").value);
            const checkIn = new Date(document.getElementById("check-in-date").value);
            const checkOut = new Date(document.getElementById("check-out-date").value);
            const resultBox = document.getElementById("enquiry-result");

            if (isNaN(checkIn.getTime()) || isNaN(checkOut.getTime()) || checkOut <= checkIn) {
                alert("Please pick valid check-in and check-out dates.");
                return;
            }

            const diffTime = Math.abs(checkOut - checkIn);
            const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
            const totalCost = diffDays * rate;

            resultBox.textContent = `Total Stay: ${diffDays} Night(s) | Estimated Cost: R${totalCost.toLocaleString()}`;

            try {
                await fetch("https://httpbin.org", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ days: diffDays, cost: totalCost })
                });
            } catch (err) {
                console.log("Asynchronous simulation finished.");
            }
        });
    }

    const checkInInput = document.getElementById("check-in-date");
    const checkOutInput = document.getElementById("check-out-date");
    if (checkInInput && checkOutInput) {
        const today = new Date().toISOString().split("T")[0];
        checkInInput.min = today;
        checkOutInput.min = today;
        checkInInput.addEventListener("change", () => {
            checkOutInput.min = checkInInput.value;
        });
    }
});
